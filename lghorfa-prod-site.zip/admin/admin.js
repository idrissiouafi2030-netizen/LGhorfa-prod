import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm';

const { url: SB_URL, key: SB_KEY } = window.LG_CONFIG;
const sb = createClient(SB_URL, SB_KEY, { auth: { persistSession: true, autoRefreshToken: true } });
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pubUrl = (b, p) => (p ? `${SB_URL}/storage/v1/object/public/${b}/${p.split('/').map(encodeURIComponent).join('/')}` : '');
const fdate = (d) => new Date(d).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' });
const app = $('#app');
let toastT;
function toast(msg, err = false) {
  const el = $('#toast'); el.textContent = msg; el.className = `toast show${err ? ' err' : ''}`;
  clearTimeout(toastT); toastT = setTimeout(() => { el.className = 'toast'; }, 3200);
}
const errMsg = (e) => (e && e.code === '23505' ? 'Cette valeur existe déjà (identifiant unique).' : (e && e.message) || 'Erreur inconnue.');

/* ---------- Schéma du CMS ---------- */
const ICON_OPTS = [['beat', 'Beat'], ['mic', 'Micro'], ['mix', 'Mixage'], ['master', 'Mastering'], ['prod', 'Production']];
const ENT = {
  projects: {
    label: 'Projets', one: 'projet', table: 'projects', order: [['sort_order', true], ['created_at', false]], title: (r) => r.title, thumb: (r) => ['images', r.cover_path], pub: 'status', feat: 'is_featured', preview: true,
    fields: [
      { k: 'title', l: 'Titre', t: 'text', req: 1 }, { k: 'slug', l: 'Identifiant URL', t: 'slug', from: 'title', h: 'Généré automatiquement si vide.' },
      { k: 'description', l: 'Description', t: 'textarea', bi: 1 }, { k: 'cover_path', l: 'Pochette', t: 'image', folder: 'projects' },
      { k: 'release_date', l: 'Date de sortie', t: 'date' }, { k: 'status', l: 'Statut', t: 'select', opts: [['draft', 'Brouillon (invisible)'], ['published', 'Publié']] },
      { k: 'is_featured', l: 'Mettre à la une', t: 'bool' }, { k: 'sort_order', l: 'Ordre d’affichage', t: 'number', h: 'Le plus petit nombre s’affiche en premier.' },
      { k: '_artists', l: 'Artistes du projet', t: 'artists' }
    ]
  },
  artists: {
    label: 'Artistes', one: 'artiste', table: 'artists', order: [['sort_order', true], ['name', true]], title: (r) => r.name, thumb: (r) => ['images', r.photo_path], pub: 'is_published', preview: true,
    fields: [
      { k: 'name', l: 'Nom', t: 'text', req: 1 }, { k: 'slug', l: 'Identifiant URL', t: 'slug', from: 'name' },
      { k: 'bio', l: 'Biographie', t: 'textarea', bi: 1 }, { k: 'photo_path', l: 'Photo', t: 'image', folder: 'artists' },
      { k: 'instagram_url', l: 'Instagram', t: 'url' }, { k: 'spotify_url', l: 'Spotify', t: 'url' }, { k: 'youtube_url', l: 'YouTube', t: 'url' },
      { k: 'is_published', l: 'Visible sur le site', t: 'bool' }, { k: 'sort_order', l: 'Ordre d’affichage', t: 'number' }
    ]
  },
  services: {
    label: 'Services', one: 'service', table: 'services', order: [['sort_order', true]], title: (r) => r.title_fr || r.title_en, pub: 'is_published',
    fields: [
      { k: 'title', l: 'Titre', t: 'text', bi: 1, req: 1 }, { k: 'slug', l: 'Identifiant URL', t: 'slug', from: 'title_en' },
      { k: 'description', l: 'Description', t: 'textarea', bi: 1 }, { k: 'icon', l: 'Icône', t: 'select', opts: ICON_OPTS },
      { k: 'is_published', l: 'Visible sur le site', t: 'bool' }, { k: 'sort_order', l: 'Ordre d’affichage', t: 'number' }
    ]
  },
  tracks: {
    label: 'Pistes audio', one: 'piste', table: 'tracks', order: [['sort_order', true], ['created_at', false]], title: (r) => r.title, pub: 'is_published',
    fields: [
      { k: 'title', l: 'Titre', t: 'text', req: 1 }, { k: 'audio_path', l: 'Fichier audio (MP3, WAV, M4A, OGG, FLAC, 50 Mo max)', t: 'audio', folder: 'tracks', req: 1 },
      { k: 'project_id', l: 'Projet associé', t: 'select', from: 'projects' }, { k: 'duration_seconds', l: 'Durée (secondes)', t: 'number', h: 'Remplie automatiquement à l’envoi du fichier.' },
      { k: 'is_published', l: 'Visible sur le site', t: 'bool' }, { k: 'sort_order', l: 'Ordre d’affichage', t: 'number' }
    ]
  },
  gallery_items: {
    label: 'Galerie', one: 'visuel', table: 'gallery_items', order: [['sort_order', true], ['created_at', false]], title: (r) => r.title_fr || r.title_en || 'Sans titre', thumb: (r) => ['images', r.image_path], pub: 'is_published',
    fields: [
      { k: 'image_path', l: 'Image', t: 'image', folder: 'gallery', req: 1 }, { k: 'title', l: 'Titre', t: 'text', bi: 1 },
      { k: 'category', l: 'Catégorie', t: 'select', opts: [['cover', 'Pochette'], ['artwork', 'Artwork'], ['audiovisual', 'Audiovisuel']] },
      { k: 'project_id', l: 'Projet associé', t: 'select', from: 'projects' }, { k: 'video_url', l: 'Lien vidéo (optionnel)', t: 'url' },
      { k: 'is_published', l: 'Visible sur le site', t: 'bool' }, { k: 'sort_order', l: 'Ordre d’affichage', t: 'number' }
    ]
  },
  social_links: {
    label: 'Réseaux sociaux', one: 'réseau', table: 'social_links', order: [['sort_order', true]], title: (r) => r.platform, pub: 'is_visible',
    fields: [
      { k: 'platform', l: 'Plateforme (ex. Instagram)', t: 'text', req: 1 }, { k: 'url', l: 'Lien complet (https://…)', t: 'url', req: 1 },
      { k: 'is_visible', l: 'Visible sur le site', t: 'bool' }, { k: 'sort_order', l: 'Ordre d’affichage', t: 'number' }
    ]
  }
};
const keysOf = (f) => (f.bi ? [`${f.k}_en`, `${f.k}_fr`] : [f.k]);
const DEFAULTS = { is_published: false, is_visible: true, is_featured: false, status: 'draft', category: 'artwork', sort_order: 0 };
const slugify = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

const NAV = [['dashboard', 'Tableau de bord'], ['projects', 'Projets'], ['artists', 'Artistes'], ['services', 'Services'], ['tracks', 'Pistes audio'], ['gallery', 'Galerie'], ['content', 'Textes du site'], ['settings', 'Contact'], ['socials', 'Réseaux sociaux'], ['seo', 'SEO'], ['messages', 'Messages']];
let session = null, unread = 0;

/* ---------- Authentification ---------- */
async function checkAdmin() {
  const { data, error } = await sb.from('admins').select('user_id').maybeSingle();
  return !error && !!data;
}
function loginView(msg = '') {
  app.innerHTML = `<div class="login"><form id="lf" autocomplete="on">
    <img src="../assets/badge-192.png" alt="LGhorfa Prod"><h1>Administration</h1><p class="mut" style="text-align:center;margin:4px 0 18px">LGhorfa Prod</p>
    <div class="fld"><label class="l" for="em">Email</label><input id="em" type="email" autocomplete="username" required></div>
    <div class="fld" style="margin-top:12px"><label class="l" for="pw">Mot de passe</label><input id="pw" type="password" autocomplete="current-password" required></div>
    <p class="err" id="le" role="alert">${esc(msg)}</p>
    <button class="btn" style="width:100%" type="submit">Se connecter</button></form></div>`;
  $('#lf').onsubmit = async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button'); btn.disabled = true; $('#le').textContent = '';
    const { error } = await sb.auth.signInWithPassword({ email: $('#em').value.trim(), password: $('#pw').value });
    if (error) { btn.disabled = false; $('#le').textContent = 'Identifiants incorrects.'; return; }
    await start();
  };
}
async function logout() { await sb.auth.signOut(); session = null; loginView(); }

/* ---------- Coque ---------- */
async function refreshUnread() {
  const { count } = await sb.from('contact_submissions').select('id', { count: 'exact', head: true }).eq('is_read', false);
  unread = count || 0;
}
function shell() {
  app.innerHTML = `<div class="shell"><aside class="side" id="side"><div class="logo"><img src="../assets/badge-192.png" alt=""><span>LGhorfa Prod</span></div>
    <nav aria-label="Administration">${NAV.map(([id, l]) => `<a href="#/${id}" data-nav="${id}">${esc(l)}${id === 'messages' && unread ? `<span class="badge">${unread}</span>` : ''}</a>`).join('')}</nav>
    <div style="padding:18px 8px 0"><a href="../" target="_blank" rel="noopener">Voir le site public</a><br><br><button class="btn ghost sm" id="lo">Se déconnecter</button></div></aside>
    <div class="main"><div class="bar"><button class="btn ghost sm menu-btn" id="mb" aria-label="Menu">Menu</button><span class="mut sp">${esc(session.user.email)}</span></div><div id="view"></div></div></div>`;
  $('#lo').onclick = logout;
  $('#mb').onclick = () => $('#side').classList.toggle('open');
  $('#side').onclick = (e) => { if (e.target.closest('a[data-nav]')) $('#side').classList.remove('open'); };
}

/* ---------- Routeur ---------- */
const view = () => $('#view');
async function route() {
  if (!session) return;
  const [, name = 'dashboard', arg] = location.hash.split('/');
  $$('[data-nav]').forEach((a) => a.setAttribute('aria-current', a.dataset.nav === name ? 'page' : 'false'));
  const map = { dashboard, content, settings, seo, messages, projects: () => listView('projects', arg), artists: () => listView('artists', arg), services: () => listView('services', arg), tracks: () => listView('tracks', arg), gallery: () => listView('gallery_items', arg), socials: () => listView('social_links', arg) };
  const v = view(); v.onclick = v.onsubmit = v.onchange = null;
  v.innerHTML = '<p class="mut">Chargement…</p>';
  try { await (map[name] || dashboard)(); } catch (e) { view().innerHTML = `<p class="err">${esc(errMsg(e))}</p>`; }
  window.scrollTo(0, 0);
}
window.addEventListener('hashchange', route);

/* ---------- Tableau de bord ---------- */
const ENT_LABEL = { projects: 'Projet', artists: 'Artiste', services: 'Service', tracks: 'Piste', gallery_items: 'Galerie', site_content: 'Texte', site_settings: 'Contact', seo_pages: 'SEO', social_links: 'Réseau social' };
const ACT_LABEL = { INSERT: 'ajouté', UPDATE: 'modifié', DELETE: 'supprimé' };
async function dashboard() {
  const cnt = async (tb, f) => { let q = sb.from(tb).select('id', { count: 'exact', head: true }); if (f) q = f(q); const { count } = await q; return count || 0; };
  const [tp, pp, dp, ta, tt, tg, um, act] = await Promise.all([
    cnt('projects'), cnt('projects', (q) => q.eq('status', 'published')), cnt('projects', (q) => q.eq('status', 'draft')), cnt('artists'), cnt('tracks'), cnt('gallery_items'),
    cnt('contact_submissions', (q) => q.eq('is_read', false)),
    sb.from('activity_log').select('*').order('created_at', { ascending: false }).limit(12)
  ]);
  unread = um;
  const st = (n, l) => `<div class="card stat"><b>${n}</b><span>${l}</span></div>`;
  view().innerHTML = `<h1>Tableau de bord</h1><p class="mut">Tout ce que vous modifiez ici apparaît sur le site public.</p>
    <div class="grid stats" style="margin:18px 0">${st(tp, 'Projets au total')}${st(pp, 'Projets publiés')}${st(dp, 'Brouillons')}${st(ta, 'Artistes')}${st(tt, 'Pistes audio')}${st(tg, 'Visuels')}${st(um, 'Messages non lus')}</div>
    <div class="grid two"><div class="card"><h2>Actions rapides</h2><div class="qa">
      <a class="btn sm" href="#/projects/new">Nouveau projet</a><a class="btn sm" href="#/artists/new">Nouvel artiste</a><a class="btn sm" href="#/tracks/new">Nouvelle piste</a><a class="btn sm" href="#/gallery/new">Nouveau visuel</a>
      <a class="btn ghost sm" href="#/content">Modifier l’accueil</a><a class="btn ghost sm" href="#/messages">Messages</a></div></div>
      <div class="card"><h2>Activité récente</h2><ul class="act">${(act.data || []).map((a) => `<li><span>${esc(ENT_LABEL[a.entity] || a.entity)} ${esc(ACT_LABEL[a.action] || a.action)}${a.label ? ` : ${esc(a.label)}` : ''}</span><time>${esc(fdate(a.created_at))}</time></li>`).join('') || '<li class="mut">Aucune activité pour le moment.</li>'}</ul></div></div>`;
  const b = $('[data-nav="messages"]'); if (b) b.innerHTML = `Messages${unread ? `<span class="badge">${unread}</span>` : ''}`;
}

/* ---------- CRUD générique ---------- */
async function listView(key, arg) {
  const ent = ENT[key];
  if (arg) return formView(key, arg);
  let q = sb.from(ent.table).select('*');
  for (const [c, asc] of ent.order) q = q.order(c, { ascending: asc });
  const { data, error } = await q; if (error) throw error;
  const isOn = (r) => (ent.pub === 'status' ? r.status === 'published' : r[ent.pub]);
  const slug = key === 'gallery_items' ? 'gallery' : key === 'social_links' ? 'socials' : key;
  view().innerHTML = `<div class="bar"><div><h1>${esc(ent.label)}</h1><span class="mut">${data.length} élément(s)</span></div><a class="btn sp" href="#/${slug}/new">Ajouter</a></div>
    <div class="rows">${data.map((r) => {
    const th = ent.thumb && ent.thumb(r);
    return `<div class="row">${th && th[1] ? `<img class="th" alt="" loading="lazy" src="${esc(pubUrl(th[0], th[1]))}">` : ''}
      <div class="t"><b>${esc(ent.title(r))}</b><small><span class="pill${isOn(r) ? ' on' : ''}">${isOn(r) ? (ent.pub === 'status' ? 'Publié' : 'Visible') : (ent.pub === 'status' ? 'Brouillon' : 'Masqué')}</span>${ent.feat && r[ent.feat] ? ' <span class="pill ft">À la une</span>' : ''}</small></div>
      <div class="acts"><a class="btn ghost sm" href="#/${slug}/${r.id}">Modifier</a>
      <button class="btn ghost sm" data-tg="${r.id}">${isOn(r) ? 'Dépublier' : 'Publier'}</button>${ent.feat ? `<button class="btn ghost sm" data-ft="${r.id}">${r[ent.feat] ? 'Retirer de la une' : 'Mettre à la une'}</button>` : ''}
      <button class="btn bad sm" data-del="${r.id}">Supprimer</button></div></div>`;
  }).join('') || `<p class="mut">Rien pour le moment. Ajoutez le premier ${esc(ent.one)}.</p>`}</div>`;
  view().onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    const row = data.find((r) => r.id === (b.dataset.tg || b.dataset.ft || b.dataset.del)); if (!row) return;
    try {
      if (b.dataset.tg) {
        const patch = ent.pub === 'status' ? { status: isOn(row) ? 'draft' : 'published' } : { [ent.pub]: !isOn(row) };
        const { error: er } = await sb.from(ent.table).update(patch).eq('id', row.id); if (er) throw er; toast(isOn(row) ? 'Dépublié.' : 'Publié.');
      } else if (b.dataset.ft) {
        const { error: er } = await sb.from(ent.table).update({ [ent.feat]: !row[ent.feat] }).eq('id', row.id); if (er) throw er; toast('Mis à jour.');
      } else if (b.dataset.del) {
        if (!confirm(`Supprimer définitivement « ${ent.title(row)} » ?`)) return;
        const { error: er } = await sb.from(ent.table).delete().eq('id', row.id); if (er) throw er;
        for (const f of ent.fields) if ((f.t === 'image' || f.t === 'audio') && row[f.k]) sb.storage.from(f.t === 'audio' ? 'audio' : 'images').remove([row[f.k]]);
        toast('Supprimé.');
      }
      listView(key);
    } catch (er) { toast(errMsg(er), true); }
  };
}

let cache = {};
async function formView(key, id) {
  const ent = ENT[key];
  const slug = key === 'gallery_items' ? 'gallery' : key === 'social_links' ? 'socials' : key;
  let row = {};
  if (id !== 'new') { const { data, error } = await sb.from(ent.table).select('*').eq('id', id).maybeSingle(); if (error || !data) throw new Error('Élément introuvable.'); row = data; }
  cache = {};
  if (ent.fields.some((f) => f.from === 'projects')) cache.projects = (await sb.from('projects').select('id,title').order('title')).data || [];
  let linked = [];
  if (ent.fields.some((f) => f.t === 'artists')) {
    cache.artists = (await sb.from('artists').select('id,name').order('name')).data || [];
    if (id !== 'new') linked = ((await sb.from('project_artists').select('artist_id').eq('project_id', id)).data || []).map((x) => x.artist_id);
  }
  const val = (k) => (row[k] ?? DEFAULTS[k] ?? '');
  const fld = (f) => {
    const L = `<label class="l" for="f_${f.k}">${esc(f.l)}${f.req ? ' *' : ''}</label>`, H = f.h ? `<div class="h">${esc(f.h)}</div>` : '';
    if (f.bi) {
      const tag = f.t === 'textarea' ? (k, v) => `<textarea name="${k}" id="f_${k}">${esc(v)}</textarea>` : (k, v) => `<input type="text" name="${k}" id="f_${k}" value="${esc(v)}">`;
      return `<div class="fld">${L.replace(`f_${f.k}`, `f_${f.k}_en`)}<div class="bi"><div><small>English</small>${tag(`${f.k}_en`, val(`${f.k}_en`))}</div><div><small>Français</small>${tag(`${f.k}_fr`, val(`${f.k}_fr`))}</div></div>${H}</div>`;
    }
    if (f.t === 'bool') return `<div class="fld"><label class="chk"><input type="checkbox" name="${f.k}" ${val(f.k) ? 'checked' : ''}> ${esc(f.l)}</label>${H}</div>`;
    if (f.t === 'textarea') return `<div class="fld">${L}<textarea name="${f.k}" id="f_${f.k}">${esc(val(f.k))}</textarea>${H}</div>`;
    if (f.t === 'select') {
      const opts = f.from ? [['', 'Aucun'], ...cache.projects.map((p) => [p.id, p.title])] : f.opts;
      return `<div class="fld">${L}<select name="${f.k}" id="f_${f.k}">${opts.map(([v, l]) => `<option value="${esc(v)}" ${String(val(f.k)) === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>${H}</div>`;
    }
    if (f.t === 'image' || f.t === 'audio') {
      const bucket = f.t === 'audio' ? 'audio' : 'images', v = val(f.k);
      return `<div class="fld">${L}<div class="up"><input type="hidden" name="${f.k}" value="${esc(v)}">
        ${f.t === 'image' ? `<img id="pv_${f.k}" alt="" ${v ? `src="${esc(pubUrl(bucket, v))}"` : 'hidden'}>` : `<audio id="pv_${f.k}" controls ${v ? `src="${esc(pubUrl(bucket, v))}"` : 'hidden'}></audio>`}
        <input type="file" id="f_${f.k}" data-up="${f.k}" data-bucket="${bucket}" data-folder="${f.folder}" accept="${f.t === 'audio' ? 'audio/mpeg,audio/wav,audio/mp4,audio/aac,audio/ogg,audio/flac,.mp3,.wav,.m4a,.ogg,.flac' : 'image/jpeg,image/png,image/webp,image/avif'}"></div>${H || `<div class="h">${f.t === 'image' ? 'JPG, PNG, WebP ou AVIF, 10 Mo max.' : ''}</div>`}</div>`;
    }
    if (f.t === 'artists') return `<div class="fld"><span class="l">${esc(f.l)}</span><div class="picks">${cache.artists.map((a) => `<label><input type="checkbox" name="_artist" value="${a.id}" ${linked.includes(a.id) ? 'checked' : ''}> ${esc(a.name)}</label>`).join('') || '<span class="mut">Ajoutez d’abord des artistes.</span>'}</div></div>`;
    const type = f.t === 'slug' ? 'text' : f.t;
    return `<div class="fld">${L}<input type="${type}" name="${f.k}" id="f_${f.k}" value="${esc(val(f.k))}"${type === 'number' ? ' min="0"' : ''}${type === 'url' ? ' placeholder="https://"' : ''}>${H}</div>`;
  };
  view().innerHTML = `<div class="bar"><a class="btn ghost sm" href="#/${slug}">Retour</a><h1>${id === 'new' ? 'Nouveau' : 'Modifier'} ${esc(ent.one)}</h1></div>
    <form class="f" id="ef" novalidate>${ent.fields.map(fld).join('')}<p class="err" id="fe" role="alert"></p>
    <div class="qa"><button class="btn" type="submit">Enregistrer</button>${ent.preview ? '<button class="btn ghost" type="button" id="pvb">Aperçu</button>' : ''}</div></form>`;
  const form = $('#ef');

  form.addEventListener('change', async (e) => {
    const inp = e.target.closest('input[data-up]'); if (!inp || !inp.files[0]) return;
    const file = inp.files[0], isAudio = inp.dataset.bucket === 'audio';
    const okType = isAudio ? file.type.startsWith('audio/') : /^image\/(jpeg|png|webp|avif)$/.test(file.type);
    if (!okType) { toast('Format de fichier non accepté.', true); inp.value = ''; return; }
    if (file.size > (isAudio ? 50 : 10) * 1048576) { toast(`Fichier trop lourd (${isAudio ? 50 : 10} Mo max).`, true); inp.value = ''; return; }
    inp.disabled = true; toast('Envoi en cours…');
    try {
      const ext = (file.name.split('.').pop() || 'bin').toLowerCase().replace(/[^a-z0-9]/g, '');
      const path = `${inp.dataset.folder}/${crypto.randomUUID()}.${ext}`;
      const { error } = await sb.storage.from(inp.dataset.bucket).upload(path, file, { contentType: file.type, cacheControl: '31536000' });
      if (error) throw error;
      form.elements[inp.dataset.up].value = path;
      const pv = $(`#pv_${inp.dataset.up}`); pv.src = pubUrl(inp.dataset.bucket, path); pv.hidden = false;
      if (isAudio && form.elements.duration_seconds) {
        const a = new Audio(URL.createObjectURL(file));
        a.addEventListener('loadedmetadata', () => { if (isFinite(a.duration)) form.elements.duration_seconds.value = Math.round(a.duration); });
      }
      toast('Fichier envoyé. Pensez à enregistrer.');
    } catch (er) { toast(errMsg(er), true); } finally { inp.disabled = false; }
  });

  const collect = () => {
    const o = {};
    for (const f of ent.fields) {
      if (f.t === 'artists') continue;
      for (const k of keysOf(f)) {
        const el = form.elements[k]; let v;
        if (f.t === 'bool') v = el.checked;
        else if (f.t === 'number') v = el.value === '' ? null : parseInt(el.value, 10);
        else v = el.value.trim();
        if (v === '') v = null;
        if (k === 'sort_order' && v === null) v = 0;
        o[k] = v;
      }
    }
    return o;
  };
  const pvb = $('#pvb');
  if (pvb) pvb.onclick = () => preview(key, collect(), [...form.querySelectorAll('input[name=_artist]:checked')].map((c) => cache.artists.find((a) => a.id === c.value)?.name).filter(Boolean));

  form.onsubmit = async (e) => {
    e.preventDefault();
    const fe = $('#fe'); fe.textContent = '';
    const p = collect();
    for (const f of ent.fields) {
      if (!f.req) continue;
      if (keysOf(f).some((k) => p[k] === null || p[k] === undefined)) { fe.textContent = `Le champ « ${f.l} » est obligatoire.`; return; }
    }
    const sf = ent.fields.find((f) => f.t === 'slug');
    if (sf && !p[sf.k]) p[sf.k] = slugify(p[sf.from]) || `item-${Date.now().toString(36)}`; else if (sf) p[sf.k] = slugify(p[sf.k]);
    if (p.url && !/^https?:\/\//i.test(p.url)) { fe.textContent = 'Le lien doit commencer par https://'; return; }
    for (const k of ['instagram_url', 'spotify_url', 'youtube_url', 'video_url']) if (p[k] && !/^https?:\/\//i.test(p[k])) { fe.textContent = 'Les liens doivent commencer par https://'; return; }
    const btn = form.querySelector('button[type=submit]'); btn.disabled = true;
    try {
      const r = id === 'new' ? await sb.from(ent.table).insert(p).select().single() : await sb.from(ent.table).update(p).eq('id', id).select().single();
      if (r.error) throw r.error;
      if (key === 'projects') {
        const ids = [...form.querySelectorAll('input[name=_artist]:checked')].map((c) => c.value);
        const d = await sb.from('project_artists').delete().eq('project_id', r.data.id); if (d.error) throw d.error;
        if (ids.length) { const i = await sb.from('project_artists').insert(ids.map((a) => ({ project_id: r.data.id, artist_id: a }))); if (i.error) throw i.error; }
      }
      toast('Enregistré. Visible sur le site si publié.');
      location.hash = `#/${slug}`;
    } catch (er) { fe.textContent = errMsg(er); btn.disabled = false; }
  };
}

function preview(key, p, names) {
  const m = $('#modal');
  const draft = key === 'projects' ? p.status !== 'published' : !p.is_published;
  const img = key === 'projects' ? p.cover_path : p.photo_path;
  const paras = (s) => esc(s || '').split(/\n{2,}/).map((x) => `<p>${x.replace(/\n/g, '<br>')}</p>`).join('');
  m.innerHTML = `<div class="pv"><p class="pv-note">${draft ? 'Brouillon : invisible sur le site tant que vous ne publiez pas.' : 'Tel qu’il apparaîtra sur le site.'}</p>
    ${img ? `<img src="${esc(pubUrl('images', img))}" alt="">` : ''}<h2>${esc(p.title || p.name || '')}</h2>
    ${names && names.length ? `<p class="mut">Avec ${esc(names.join(', '))}</p>` : ''}
    <h3>English</h3>${paras(p.description_en || p.bio_en)}<h3>Français</h3>${paras(p.description_fr || p.bio_fr)}</div>
    <p><button class="btn" id="pvx">Fermer</button></p>`;
  $('#pvx').onclick = () => m.close(); m.showModal();
}

/* ---------- Textes du site ---------- */
const SEC_LABEL = { home: 'Accueil', about: 'Le studio', services: 'Section Services', productions: 'Section Productions', artists: 'Section Artistes', audio: 'Section Audio', visual: 'Section Visuels', contact: 'Section Contact' };
const KEY_LABEL = { headline: 'Titre principal', subtitle: 'Sous-titre', cta_primary: 'Bouton principal', cta_secondary: 'Bouton secondaire', title: 'Titre', intro: 'Introduction', body: 'Texte (séparez les paragraphes par une ligne vide)', vision: 'Phrase forte', background: 'Image de fond' };
async function content() {
  const { data, error } = await sb.from('site_content').select('*').order('section').order('key'); if (error) throw error;
  const bg = data.find((r) => r.section === 'home' && r.key === 'background');
  const secs = Object.keys(SEC_LABEL);
  const rows = data.filter((r) => r.key !== 'background').sort((a, b) => secs.indexOf(a.section) - secs.indexOf(b.section));
  view().innerHTML = `<h1>Textes du site</h1><p class="mut">Chaque texte existe en anglais et en français.</p><div class="grid" style="margin-top:16px">
    <div class="card"><h2>Image de fond de l’accueil</h2><div class="up">${bg && bg.image_path ? `<img id="bgp" alt="" src="${esc(pubUrl('images', bg.image_path))}">` : '<img id="bgp" alt="" hidden>'}
      <input type="file" id="bgf" accept="image/jpeg,image/png,image/webp,image/avif">${bg && bg.image_path ? '<button class="btn bad sm" id="bgx">Retirer</button>' : ''}</div></div>
    ${rows.map((r) => `<form class="card f" data-s="${esc(r.section)}" data-k="${esc(r.key)}"><h3>${esc(SEC_LABEL[r.section] || r.section)} : ${esc(KEY_LABEL[r.key] || r.key)}</h3>
      <div class="bi"><div><small>English</small><textarea name="en" style="min-height:${r.key === 'body' ? 180 : 70}px">${esc(r.value_en)}</textarea></div><div><small>Français</small><textarea name="fr" style="min-height:${r.key === 'body' ? 180 : 70}px">${esc(r.value_fr)}</textarea></div></div>
      <div><button class="btn sm" type="submit">Enregistrer</button></div></form>`).join('')}</div>`;
  view().onsubmit = async (e) => {
    e.preventDefault(); const f = e.target;
    const { error: er } = await sb.from('site_content').update({ value_en: f.elements.en.value.trim() || null, value_fr: f.elements.fr.value.trim() || null }).eq('section', f.dataset.s).eq('key', f.dataset.k);
    toast(er ? errMsg(er) : 'Enregistré.', !!er);
  };
  const setBg = async (path) => { const { error: er } = await sb.from('site_content').upsert({ section: 'home', key: 'background', image_path: path }); if (er) throw er; };
  const bf = $('#bgf');
  bf.onchange = async () => {
    const file = bf.files[0]; if (!file) return;
    if (!/^image\/(jpeg|png|webp|avif)$/.test(file.type) || file.size > 10485760) { toast('Image invalide (JPG/PNG/WebP/AVIF, 10 Mo max).', true); return; }
    try {
      const path = `site/${crypto.randomUUID()}.${file.type.split('/')[1]}`;
      const up = await sb.storage.from('images').upload(path, file, { contentType: file.type, cacheControl: '31536000' }); if (up.error) throw up.error;
      await setBg(path); toast('Image de fond mise à jour.'); content();
    } catch (er) { toast(errMsg(er), true); }
  };
  const bx = $('#bgx'); if (bx) bx.onclick = async () => { try { await setBg(null); toast('Image retirée.'); content(); } catch (er) { toast(errMsg(er), true); } };
}

/* ---------- Coordonnées + mot de passe ---------- */
const SET = [['contact_email', 'Email de contact public', 'email'], ['phone', 'Téléphone', 'text'], ['whatsapp', 'WhatsApp (avec indicatif, ex. +212…)', 'text'], ['location', 'Lieu / ville', 'text']];
async function settings() {
  const { data, error } = await sb.from('site_settings').select('*'); if (error) throw error;
  const v = Object.fromEntries(data.map((r) => [r.key, r.value]));
  view().innerHTML = `<h1>Coordonnées</h1><p class="mut">Ces informations s’affichent dans la section Contact. Laissez vide pour masquer.</p>
    <form class="f card" id="sf" style="margin-top:16px">${SET.map(([k, l, t]) => `<div class="fld"><label class="l" for="s_${k}">${esc(l)}</label><input type="${t}" id="s_${k}" name="${k}" value="${esc(v[k] || '')}"></div>`).join('')}<div><button class="btn" type="submit">Enregistrer</button></div></form>
    <form class="f card" id="pf" style="margin-top:18px"><h2>Changer le mot de passe</h2><div class="fld"><label class="l" for="np">Nouveau mot de passe (12 caractères minimum)</label><input type="password" id="np" autocomplete="new-password" minlength="12"></div><p class="err" id="pe" role="alert"></p><div><button class="btn ghost" type="submit">Mettre à jour</button></div></form>`;
  $('#sf').onsubmit = async (e) => {
    e.preventDefault(); const f = e.target;
    const ops = SET.map(([k]) => (f.elements[k].value.trim() ? sb.from('site_settings').upsert({ key: k, value: f.elements[k].value.trim() }) : sb.from('site_settings').delete().eq('key', k)));
    const res = await Promise.all(ops); const er = res.find((r) => r.error);
    toast(er ? errMsg(er.error) : 'Enregistré.', !!er);
  };
  $('#pf').onsubmit = async (e) => {
    e.preventDefault(); const pw = $('#np').value;
    if (pw.length < 12) { $('#pe').textContent = 'Au moins 12 caractères.'; return; }
    const { error: er } = await sb.auth.updateUser({ password: pw });
    if (er) { $('#pe').textContent = errMsg(er); return; }
    $('#pe').textContent = ''; $('#np').value = ''; toast('Mot de passe mis à jour.');
  };
}

/* ---------- SEO ---------- */
const PAGE_LABEL = { home: 'Accueil', about: 'Le studio', services: 'Services', productions: 'Productions', artists: 'Artistes', audio: 'Audio', 'visual-works': 'Visuels', contact: 'Contact' };
async function seo() {
  const { data, error } = await sb.from('seo_pages').select('*'); if (error) throw error;
  const order = Object.keys(PAGE_LABEL);
  view().innerHTML = `<h1>SEO</h1><p class="mut">Titre (60 caractères conseillés) et description (155 caractères conseillés) affichés par Google et lors des partages. Le site utilise ceux de « Accueil ».</p><div class="grid" style="margin-top:16px">
    ${data.sort((a, b) => order.indexOf(a.page) - order.indexOf(b.page)).map((r) => `<form class="card f" data-p="${esc(r.page)}"><h3>${esc(PAGE_LABEL[r.page] || r.page)}</h3>
      <div class="bi"><div><small>Titre (EN)</small><input type="text" name="title_en" value="${esc(r.title_en)}"></div><div><small>Titre (FR)</small><input type="text" name="title_fr" value="${esc(r.title_fr)}"></div></div>
      <div class="bi"><div><small>Description (EN)</small><textarea name="description_en" style="min-height:80px">${esc(r.description_en)}</textarea></div><div><small>Description (FR)</small><textarea name="description_fr" style="min-height:80px">${esc(r.description_fr)}</textarea></div></div>
      ${r.page === 'home' ? `<div class="up"><input type="hidden" name="og_image_path" value="${esc(r.og_image_path)}"><img id="ogp" alt="" ${r.og_image_path ? `src="${esc(pubUrl('images', r.og_image_path))}"` : 'hidden'}><div><small class="mut">Image de partage (1200×630 conseillé)</small><br><input type="file" data-og accept="image/jpeg,image/png,image/webp"></div></div>` : ''}
      <div><button class="btn sm" type="submit">Enregistrer</button></div></form>`).join('')}</div>`;
  view().onchange = async (e) => {
    const inp = e.target.closest('input[data-og]'); if (!inp || !inp.files[0]) return;
    const file = inp.files[0];
    if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size > 10485760) { toast('Image invalide.', true); return; }
    const path = `site/og-${crypto.randomUUID()}.${file.type.split('/')[1]}`;
    const up = await sb.storage.from('images').upload(path, file, { contentType: file.type, cacheControl: '31536000' });
    if (up.error) { toast(errMsg(up.error), true); return; }
    inp.closest('form').elements.og_image_path.value = path; const p = $('#ogp'); p.src = pubUrl('images', path); p.hidden = false; toast('Image envoyée. Enregistrez.');
  };
  view().onsubmit = async (e) => {
    e.preventDefault(); const f = e.target, o = {};
    for (const k of ['title_en', 'title_fr', 'description_en', 'description_fr', 'og_image_path']) if (f.elements[k]) o[k] = f.elements[k].value.trim() || null;
    const { error: er } = await sb.from('seo_pages').update(o).eq('page', f.dataset.p);
    toast(er ? errMsg(er) : 'Enregistré.', !!er);
  };
}

/* ---------- Messages ---------- */
async function messages() {
  const { data, error } = await sb.from('contact_submissions').select('*').order('created_at', { ascending: false }).limit(200); if (error) throw error;
  view().innerHTML = `<h1>Messages</h1><div class="rows" style="margin-top:16px">${data.map((m) => `<div class="card" ${m.is_read ? '' : 'style="border-color:var(--acc)"'}>
    <div class="bar" style="margin:0 0 6px"><b>${esc(m.name)}</b><span class="mut">${esc(m.email)}</span><span class="mut sp">${esc(fdate(m.created_at))} · ${esc(m.locale.toUpperCase())}</span></div>
    ${m.subject ? `<b>${esc(m.subject)}</b>` : ''}<p class="msg">${esc(m.message)}</p>
    <div class="qa" style="margin-top:10px"><a class="btn sm" href="mailto:${esc(m.email)}?subject=${encodeURIComponent('Re: ' + (m.subject || ''))}">Répondre</a>
    <button class="btn ghost sm" data-rd="${m.id}" data-v="${m.is_read}">${m.is_read ? 'Marquer non lu' : 'Marquer lu'}</button><button class="btn bad sm" data-dm="${m.id}">Supprimer</button></div></div>`).join('') || '<p class="mut">Aucun message pour le moment.</p>'}</div>`;
  view().onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.rd) { await sb.from('contact_submissions').update({ is_read: b.dataset.v !== 'true' }).eq('id', b.dataset.rd); }
    else if (b.dataset.dm) { if (!confirm('Supprimer ce message ?')) return; await sb.from('contact_submissions').delete().eq('id', b.dataset.dm); }
    else return;
    await refreshUnread(); shell(); route();
  };
}

/* ---------- Démarrage ---------- */
async function start() {
  const { data } = await sb.auth.getSession();
  if (!data.session) { loginView(); return; }
  if (!(await checkAdmin())) { await sb.auth.signOut(); loginView('Ce compte n’a pas accès à l’administration.'); return; }
  session = data.session;
  await refreshUnread(); shell(); route();
}
sb.auth.onAuthStateChange((ev) => { if (ev === 'SIGNED_OUT' && session) { session = null; loginView(); } });
start();
