import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const ASPECT = 1417 / 1322;
const H = 3.4;

const STATES = {
  home:        { x: 0,    y: 0.15, z: 0,  s: 1,    ry: 0,    ring: 1,   cz: 9 },
  about:       { x: 2.7,  y: 0,    z: -1, s: 0.8,  ry: -0.4,  ring: 0.5, cz: 9 },
  services:    { x: -2.9, y: 0.2,  z: -2, s: 0.65, ry: 0.45,  ring: 0.3, cz: 9 },
  productions: { x: 0,    y: 0.9,  z: -5, s: 0.6,  ry: 0,     ring: 0.2, cz: 9 },
  artists:     { x: 3.1,  y: -0.2, z: -3, s: 0.6,  ry: -0.35, ring: 0.3, cz: 9 },
  audio:       { x: 0,    y: 0.1,  z: 0,  s: 0.85, ry: 0,     ring: 1.5, cz: 8.6 },
  visual:      { x: -3.1, y: 0,    z: -4, s: 0.55, ry: 0.35,  ring: 0.2, cz: 9 },
  contact:     { x: 0,    y: 0.5,  z: -1.5, s: 0.9, ry: 0,    ring: 0.6, cz: 9 }
};

function buildEnv() {
  const s = new THREE.Scene();
  s.add(new THREE.Mesh(new THREE.BoxGeometry(20, 12, 20), new THREE.MeshBasicMaterial({ color: 0x050505, side: THREE.BackSide })));
  const panel = (w, h, x, y, z, col, k) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(col).multiplyScalar(k), side: THREE.DoubleSide }));
    m.position.set(x, y, z); m.lookAt(0, 0, 0); s.add(m);
  };
  panel(14, 1.2, 0, 5.6, 0, 0xffffff, 9);
  panel(2.2, 9, -8, 0, 2, 0xffd2a0, 5);
  panel(2.2, 9, 8, 0, -1, 0xa8c4ff, 4);
  panel(8, 0.8, 0, -5, 6, 0xffffff, 2.5);
  panel(10, 6, 0, 1, -9.5, 0xffffff, 1.2);
  return s;
}

export async function createScene(canvas, { low = false, reduced = false } = {}) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: !low, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, low ? 1.5 : 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.setClearColor(0x000000, 0);

  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(buildEnv(), 0.04).texture;
  pmrem.dispose();

  const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 80);
  camera.position.set(0, 0, 9);

  const key = new THREE.SpotLight(0xfff1dc, 0, 40, 0.55, 0.7, 1.2);
  key.position.set(3, 5, 7);
  const rim = new THREE.PointLight(0x8fb4ff, 0, 30, 1.5);
  rim.position.set(-5, 1, -3);
  scene.add(key, key.target, rim);

  const loader = new THREE.TextureLoader();
  const [alpha, bump] = await Promise.all([loader.loadAsync('assets/logo-alpha.png'), loader.loadAsync('assets/logo-bump.png')]);
  const aniso = renderer.capabilities.getMaxAnisotropy();
  alpha.anisotropy = bump.anisotropy = Math.min(8, aniso);

  // Logo : couches empilées = vraie épaisseur, identité du logo conservée à l'identique
  const logo = new THREE.Group();
  const layers = low ? 7 : 14;
  const gap = 0.02;
  const geo = new THREE.PlaneGeometry(H * ASPECT, H);
  for (let i = 0; i < layers; i++) {
    const front = i === layers - 1;
    const shade = front ? 0xe9e9e9 : new THREE.Color(0x1b1b1b).lerp(new THREE.Color(0x8a8a8a), i / layers);
    const mat = new THREE.MeshStandardMaterial({
      color: shade, metalness: front ? 0.95 : 0.7, roughness: front ? 0.24 : 0.5,
      alphaMap: alpha, alphaTest: 0.5, alphaToCoverage: !low,
      bumpMap: front ? bump : null, bumpScale: front ? 6 : 0, envMapIntensity: 1.25
    });
    const m = new THREE.Mesh(geo, mat);
    m.position.z = (i - layers / 2) * gap;
    logo.add(m);
  }
  const group = new THREE.Group();
  group.add(logo);

  // Anneau de barres réactif à l'audio
  const BARS = low ? 40 : 72;
  const barGeo = new THREE.BoxGeometry(0.045, 1, 0.045);
  const barMat = new THREE.MeshStandardMaterial({ color: 0xcfcfcf, metalness: 0.85, roughness: 0.35 });
  const bars = new THREE.InstancedMesh(barGeo, barMat, BARS);
  bars.position.z = -0.6;
  group.add(bars);
  scene.add(group);

  // Poussière en suspension
  const P = low ? 120 : 260;
  const pos = new Float32Array(P * 3);
  for (let i = 0; i < P; i++) { pos[i * 3] = (Math.random() - 0.5) * 24; pos[i * 3 + 1] = (Math.random() - 0.5) * 14; pos[i * 3 + 2] = -6 + Math.random() * 10; }
  const pg = new THREE.BufferGeometry();
  pg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const dust = new THREE.Points(pg, new THREE.PointsMaterial({ color: 0xffffff, size: 0.028, transparent: true, opacity: 0.45, depthWrite: false }));
  scene.add(dust);

  // État animé
  let name = 'home';
  let portrait = false;
  const cur = { ...STATES.home }, tgt = { ...STATES.home };
  let px = 0, py = 0, tpx = 0, tpy = 0, kick = 0, introK = reduced ? 1 : 0, introOn = !reduced;
  const levels = new Float32Array(BARS), tlev = new Float32Array(BARS);
  const dummy = new THREE.Object3D();

  function adapt(st) {
    if (!portrait) return st;
    return { ...st, x: st.x * 0.12, y: name === 'audio' ? 1.5 : 1.75, s: st.s * 0.62, z: st.z - 1.5 };
  }
  function setState(n) { if (!STATES[n]) return; name = n; Object.assign(tgt, adapt(STATES[n])); }

  function resize() {
    const w = canvas.clientWidth || window.innerWidth, h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    portrait = camera.aspect < 0.9;
    camera.updateProjectionMatrix();
    setState(name);
  }
  window.addEventListener('resize', resize);
  window.addEventListener('pointermove', (e) => { tpx = (e.clientX / window.innerWidth) * 2 - 1; tpy = (e.clientY / window.innerHeight) * 2 - 1; }, { passive: true });
  resize();

  let running = true, last = performance.now(), introT = 0, skip = false;
  const damp = (a, b, k) => a + (b - a) * k;

  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    const t = now / 1000;
    const k = 1 - Math.exp(-dt * 3.2);
    for (const key of ['x', 'y', 'z', 's', 'ry', 'ring', 'cz']) cur[key] = damp(cur[key], tgt[key], k);
    px = damp(px, tpx, 1 - Math.exp(-dt * 4)); py = damp(py, tpy, 1 - Math.exp(-dt * 4));

    if (introOn) {
      introT += dt;
      introK = Math.min(1, introT / 2.4);
      if (introK >= 1) introOn = false;
    }
    const e = 1 - Math.pow(1 - introK, 3);
    key.intensity = 70 * e;
    rim.intensity = 14 * e;
    camera.position.z = cur.cz + (1 - e) * 5;

    const float = reduced ? 0 : Math.sin(t * 0.8) * 0.06;
    group.position.set(cur.x, cur.y + float, cur.z);
    group.scale.setScalar(cur.s);
    group.rotation.set(py * 0.1, cur.ry + px * 0.32 + (1 - e) * -1.2, 0);

    // barres
    kick = Math.max(0, kick - dt * 1.8);
    for (let i = 0; i < BARS; i++) {
      const idle = 0.12 + 0.07 * Math.sin(t * 1.3 + i * 0.7) + 0.05 * Math.sin(t * 2.1 + i * 1.9);
      const target = (tlev.__live ? tlev[i] * 1.6 + 0.08 : idle) + kick * 0.5;
      levels[i] = damp(levels[i], target, 0.25);
      const a = (i / BARS) * Math.PI * 2;
      const len = Math.max(0.04, levels[i] * cur.ring * 1.1);
      const r = 2.75 + len / 2;
      dummy.position.set(Math.cos(a) * r, Math.sin(a) * r, 0);
      dummy.rotation.set(0, 0, a - Math.PI / 2);
      dummy.scale.set(1, len, 1);
      dummy.updateMatrix();
      bars.setMatrixAt(i, dummy.matrix);
    }
    bars.instanceMatrix.needsUpdate = true;
    bars.visible = cur.ring > 0.05;

    if (!reduced) dust.rotation.y = t * 0.01, dust.position.y = Math.sin(t * 0.15) * 0.3;
    renderer.render(scene, camera);
  }

  function loop(now) { if (!running) return; frame(now); raf = requestAnimationFrame(loop); }
  let raf = requestAnimationFrame(loop);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { running = false; cancelAnimationFrame(raf); }
    else { running = true; last = performance.now(); raf = requestAnimationFrame(loop); }
  });
  canvas.addEventListener('webglcontextlost', (ev) => ev.preventDefault());

  return {
    setState,
    pulse() { kick = 1; },
    setLevels(arr) {
      if (!arr) { tlev.__live = false; return; }
      tlev.__live = true;
      for (let i = 0; i < BARS; i++) tlev[i] = arr[Math.floor((i / BARS) * arr.length)] || 0;
    },
    startIntro() { introT = 0; introOn = !reduced; introK = reduced ? 1 : 0; },
    skipIntro() { introT = 99; }
  };
}
