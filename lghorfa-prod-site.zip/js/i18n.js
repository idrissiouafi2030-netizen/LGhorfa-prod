export const T = {
  en: {
    nav: { home: 'Home', about: 'About', services: 'Services', productions: 'Productions', artists: 'Artists', audio: 'Audio', visual: 'Visual', contact: 'Contact' },
    menu: 'Menu', close: 'Close', skip: 'Skip to content', featured: 'Featured',
    empty: {
      productions: 'No productions published yet. Check back soon.',
      artists: 'Artists will appear here soon.',
      visual: 'The gallery is being prepared.',
      audio: 'No tracks published yet.',
      services: 'Services will appear here soon.'
    },
    with: 'With', released: 'Released', tracks: 'Tracks', links: 'Links', bio: 'Biography',
    play: 'Play', pause: 'Pause', prev: 'Previous track', next: 'Next track', volume: 'Volume', seek: 'Seek',
    nowPlaying: 'Now playing', stopped: 'Pick a track to start', audioError: 'This track could not be played.',
    filters: { all: 'All', cover: 'Covers', artwork: 'Artwork', audiovisual: 'Audiovisual' },
    watch: 'Watch the video', openProject: 'Open project',
    form: {
      name: 'Your name', email: 'Email', subject: 'Subject', message: 'Your message', send: 'Send message', sending: 'Sending…',
      ok: 'Message sent. We will reply soon.', err: 'The message could not be sent. Try again in a moment.',
      invalid: 'Enter your name, a valid email and a message.', wait: 'Please wait a moment before sending another message.'
    },
    follow: 'Follow', direct: 'Direct contact', email: 'Email', phone: 'Phone', whatsapp: 'WhatsApp', location: 'Location',
    rights: 'All rights reserved.', lang: 'Language', loadError: 'Content could not be loaded. Refresh the page.', webgl: 'The 3D view is not available on this device.'
  },
  fr: {
    nav: { home: 'Accueil', about: 'Le studio', services: 'Services', productions: 'Productions', artists: 'Artistes', audio: 'Audio', visual: 'Visuels', contact: 'Contact' },
    menu: 'Menu', close: 'Fermer', skip: 'Aller au contenu', featured: 'À la une',
    empty: {
      productions: 'Aucune production publiée pour le moment. Revenez bientôt.',
      artists: 'Les artistes apparaîtront ici bientôt.',
      visual: 'La galerie est en préparation.',
      audio: 'Aucun morceau publié pour le moment.',
      services: 'Les services apparaîtront ici bientôt.'
    },
    with: 'Avec', released: 'Sortie', tracks: 'Morceaux', links: 'Liens', bio: 'Biographie',
    play: 'Lecture', pause: 'Pause', prev: 'Morceau précédent', next: 'Morceau suivant', volume: 'Volume', seek: 'Position',
    nowPlaying: 'En lecture', stopped: 'Choisissez un morceau pour commencer', audioError: 'Ce morceau n’a pas pu être lu.',
    filters: { all: 'Tout', cover: 'Pochettes', artwork: 'Artworks', audiovisual: 'Audiovisuel' },
    watch: 'Voir la vidéo', openProject: 'Ouvrir le projet',
    form: {
      name: 'Votre nom', email: 'Email', subject: 'Sujet', message: 'Votre message', send: 'Envoyer le message', sending: 'Envoi…',
      ok: 'Message envoyé. Nous répondons rapidement.', err: 'Le message n’a pas pu être envoyé. Réessayez dans un instant.',
      invalid: 'Indiquez votre nom, un email valide et un message.', wait: 'Patientez un instant avant d’envoyer un autre message.'
    },
    follow: 'Suivre', direct: 'Contact direct', email: 'Email', phone: 'Téléphone', whatsapp: 'WhatsApp', location: 'Lieu',
    rights: 'Tous droits réservés.', lang: 'Langue', loadError: 'Le contenu n’a pas pu être chargé. Actualisez la page.', webgl: 'La vue 3D n’est pas disponible sur cet appareil.'
  }
};
