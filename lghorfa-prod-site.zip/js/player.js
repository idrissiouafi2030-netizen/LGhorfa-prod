export class Player {
  constructor() {
    this.a = new Audio();
    this.a.crossOrigin = 'anonymous';
    this.a.preload = 'none';
    this.list = [];
    this.i = -1;
    this.ctx = null;
    this.an = null;
    this.buf = null;
    this.peaks = new Map();
    this.fns = new Set();
    ['play', 'pause', 'timeupdate', 'loadedmetadata', 'volumechange'].forEach((e) => this.a.addEventListener(e, () => this.emit(e)));
    this.a.addEventListener('ended', () => this.next());
    this.a.addEventListener('error', () => this.emit('error'));
  }
  on(fn) { this.fns.add(fn); }
  emit(e) { this.fns.forEach((f) => f(e, this)); }
  get cur() { return this.list[this.i] || null; }
  get playing() { return !this.a.paused; }

  setList(list) {
    const id = this.cur && this.cur.id;
    this.list = list;
    const idx = list.findIndex((t) => t.id === id);
    if (idx >= 0) this.i = idx;
    else if (this.i >= 0) { this.a.pause(); this.a.removeAttribute('src'); this.i = -1; }
    this.emit('list');
  }

  ensureCtx() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      this.ctx = new AC();
      this.an = this.ctx.createAnalyser();
      this.an.fftSize = 256;
      this.an.smoothingTimeConstant = 0.82;
      const src = this.ctx.createMediaElementSource(this.a);
      src.connect(this.an);
      this.an.connect(this.ctx.destination);
      this.buf = new Uint8Array(this.an.frequencyBinCount);
    } catch (e) { this.ctx = null; this.an = null; }
  }

  async playIndex(i) {
    const t = this.list[i];
    if (!t) return;
    this.i = i;
    if (this.a.getAttribute('src') !== t.src) this.a.src = t.src;
    this.ensureCtx();
    if (this.ctx && this.ctx.state === 'suspended') { try { await this.ctx.resume(); } catch (e) { /* ignore */ } }
    try { await this.a.play(); } catch (e) { this.emit('error'); }
    this.emit('track');
    this.loadPeaks(t);
  }
  playId(id) { const i = this.list.findIndex((t) => t.id === id); if (i >= 0) return this.playIndex(i); }
  toggle() {
    if (this.i < 0) return this.playIndex(0);
    if (this.a.paused) { if (this.ctx) this.ctx.resume(); return this.a.play().catch(() => this.emit('error')); }
    this.a.pause();
  }
  next() { if (this.list.length) this.playIndex((this.i + 1) % this.list.length); }
  prev() {
    if (!this.list.length) return;
    if (this.a.currentTime > 3) { this.a.currentTime = 0; return; }
    this.playIndex((this.i - 1 + this.list.length) % this.list.length);
  }
  seek(p) { if (this.a.duration) this.a.currentTime = Math.max(0, Math.min(1, p)) * this.a.duration; }
  setVolume(v) { this.a.volume = Math.max(0, Math.min(1, v)); }

  levels(n) {
    if (!this.an || this.a.paused) return null;
    this.an.getByteFrequencyData(this.buf);
    const out = new Float32Array(n);
    const step = Math.max(1, Math.floor((this.buf.length * 0.75) / n));
    for (let i = 0; i < n; i++) out[i] = this.buf[i * step] / 255;
    return out;
  }

  async loadPeaks(t) {
    if (this.peaks.has(t.id)) { this.emit('peaks'); return; }
    this.peaks.set(t.id, null);
    try {
      const r = await fetch(t.src);
      const ab = await r.arrayBuffer();
      if (ab.byteLength > 30e6) throw new Error('too large');
      const ctx = this.ctx || new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 1, 44100);
      const buf = await ctx.decodeAudioData(ab);
      const ch = buf.getChannelData(0), N = 200, size = Math.floor(ch.length / N) || 1;
      const p = new Float32Array(N);
      let max = 0;
      for (let i = 0; i < N; i++) {
        let m = 0;
        for (let j = 0; j < size; j += 40) m = Math.max(m, Math.abs(ch[i * size + j] || 0));
        p[i] = m; max = Math.max(max, m);
      }
      for (let i = 0; i < N; i++) p[i] = max ? p[i] / max : 0;
      this.peaks.set(t.id, p);
    } catch (e) { this.peaks.set(t.id, null); }
    this.emit('peaks');
  }
}
