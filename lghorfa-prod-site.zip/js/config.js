// Clé publique (publishable) : sans danger côté navigateur, l'accès est limité par la RLS.
window.LG_CONFIG = {
  url: 'https://yflrhxlwyxrcodcuhbow.supabase.co',
  key: 'sb_publishable_yGoX-7EaZg0BmSMlBOKFJg_LzFO-giO'
};
