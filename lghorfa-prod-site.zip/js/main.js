import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm';
import { T } from './i18n.js';
import { Player } from './player.js';

const { url: SB_URL, key: SB_KEY } = window.LG_CONFIG;
const sb = createClient(SB_URL, SB_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const SECTIONS = ['home', 'about', 'services', 'productions', 'artists', 'audio', 'visual', 'contact'];
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
const low = matchMedia('(max-width: 820px)').matches || (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 4;

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const safeUrl = (u) => (/^https?:\/\//i.test(u || '') ? u : '');
const pub = (bucket, path) => (path ? `${SB_URL}/storage/v1/object/public/${bucket}/${path.split('/').map(encodeURIComponent).join('/')}` : '');
const paras = (s) => esc(s || '').split(/\n{2,}/).map((p) => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
const fmtTime = (s) => (isFinite(s) ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}` : '0:00');

let lang = (() => {
  const q = new URLSearchParams(location.search).get('lang');
  if (q === 'fr' || q === 'en') return q;
  try { const s = localStorage.getItem('lg_lang'); if (s === 'fr' || s === 'en') return s; } catch (e) { /* ignore */ }
  return (navigator.language || 'en').toLowerCase().startsWith('fr') ? 'fr' : 'en';
})();
const t = () => T[lang];
const D = { content: {}, settings: {}, seo: {}, socials: [], services: [], artists: [], projects: [], links: [], tracks: [], gallery: [] };
const pick = (o, k) => (o && (o[`${k}_${lang}`] || o[`${k}_en`] || o[`${k}_fr`])) || '';
const C = (sec, key) => { const r = D.content[`${sec}.${key}`]; return r ? (lang === 'fr' ? r.value_fr || r.value_en : r.value_en || r.value_fr) || '' : ''; };

const player = new Player();
let scene = null;
let galleryFilter = 'all';

/* ---------- Données ---------- */
async function load() {
  const q = (tb, f) => { let r = sb.from(tb).select('*'); return f ? f(r) : r; };
  const res = await Promise.all([
    q('site_content'), q('site_settings'), q('seo_pages'),
    q('social_links', (r) => r.order('sort_order')),
    q('services', (r) => r.order('sort_order')),
    q('artists', (r) => r.order('sort_order')),
    q('projects', (r) => r.order('sort_order').order('release_date', { ascending: false })),
    q('project_artists'),
    q('tracks', (r) => r.order('sort_order')),
    q('gallery_items', (r) => r.order('sort_order'))
  ]);
  if (res.some((r) => r.error)) throw new Error(res.find((r) => r.error).error.message);
  const [content, settings, seo, socials, services, artists, projects, links, tracks, gallery] = res.map((r) => r.data || []);
  D.content = Object.fromEntries(content.map((r) => [`${r.section}.${r.key}`, r]));
  D.settings = Object.fromEntries(settings.map((r) => [r.key, r.value]));
  D.seo = Object.fromEntries(seo.map((r) => [r.page, r]));
  Object.assign(D, { socials, services, artists, projects, links, tracks, gallery });
}

/* ---------- Rendu ---------- */
const ICONS = {
  beat: '<path d="M4 28V12M12 36V4M20 30V10M28 40V0M36 26V14M44 32V8" transform="translate(0 4) scale(.9)"/>',
  mic: '<rect x="16" y="4" width="16" height="22" rx="8"/><path d="M10 22a14 14 0 0 0 28 0M24 36v8M16 44h16"/>',
  mix: '<path d="M10 6v36M24 6v36M38 6v36"/><rect x="5" y="14" width="10" height="7"/><rect x="19" y="28" width="10" height="7"/><rect x="33" y="10" width="10" height="7"/>',
  master: '<circle cx="24" cy="24" r="17"/><circle cx="24" cy="24" r="5"/><path d="M24 7v6M41 24h-6"/>',
  prod: '<path d="M6 34l10-20 8 14 6-10 12 16z"/><path d="M6 42h36"/>'
};
const icon = (n) => `<svg viewBox="0 0 48 48" aria-hidden="true">${ICONS[n] || ICONS.beat}</svg>`;
const SVG = {
  play: '<svg viewBox="0 0 20 20"><path d="M5 2l13 8-13 8z"/></svg>',
  pause: '<svg viewBox="0 0 20 20"><path d="M4 2h4v16H4zM12 2h4v16h-4z"/></svg>',
  prev: '<svg viewBox="0 0 20 20"><path d="M4 2h3v16H4zM18 2v16L8 10z"/></svg>',
  next: '<svg viewBox="0 0 20 20"><path d="M13 2h3v16h-3zM2 2l10 8L2 18z"/></svg>'
};

function renderStatic() {
  document.documentElement.lang = lang;
  $$('[data-i]').forEach((el) => { el.textContent = t()[el.dataset.i]; });
  $$('[data-f]').forEach((el) => { el.textContent = t().form[el.dataset.f]; });
  $('#nav').innerHTML = SECTIONS.map((s) => `<a href="#${s}">${esc(t().nav[s])}</a>`).join('');
  $('#sendBtn').textContent = t().form.send;
  $('#rights').textContent = t().rights;
  $('#year').textContent = `© ${new Date().getFullYear()}`;
  $$('.lang button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.lang === lang)));
  $('#menuBtn').setAttribute('aria-label', t().menu);
}

function renderContent() {
  $('#heroTitle').textContent = C('home', 'headline');
  $('#heroSub').textContent = C('home', 'subtitle');
  $('#ctaPrimary').textContent = C('home', 'cta_primary');
  $('#ctaSecondary').textContent = C('home', 'cta_secondary');
  $('#aboutTitle').textContent = C('about', 'title');
  $('#aboutBody').innerHTML = paras(C('about', 'body'));
  $('#aboutVision').textContent = C('about', 'vision');
  $('#aboutVision').hidden = !C('about', 'vision');
  for (const [id, sec] of [['services', 'services'], ['productions', 'productions'], ['artists', 'artists'], ['audio', 'audio'], ['visual', 'visual'], ['contact', 'contact']]) {
    $(`#${id}Title`).textContent = C(sec, 'title');
    $(`#${id}Intro`).textContent = C(sec, 'intro');
  }
  const bg = D.content['home.background'];
  if (bg && bg.image_path) document.body.style.setProperty('--hero-bg', `url(${pub('images', bg.image_path)})`);

  // Services
  const sv = D.services.filter((s) => s.is_published);
  $('#servicesList').innerHTML = sv.length
    ? sv.map((s) => `<li class="svc"><h3>${esc(pick(s, 'title'))}</h3><p>${esc(pick(s, 'description'))}</p>${icon(s.icon)}</li>`).join('')
    : `<li class="svc"><p>${esc(t().empty.services)}</p></li>`;

  // Productions
  const pr = D.projects.filter((p) => p.status === 'published');
  const sorted = [...pr].sort((a, b) => Number(b.is_featured) - Number(a.is_featured));
  $('#productionsGrid').innerHTML = sorted.length
    ? sorted.map((p) => {
      const names = artistsOf(p.id).map((a) => a.name).join(', ');
      const yr = p.release_date ? new Date(p.release_date).getFullYear() : '';
      return `<button class="proj${p.is_featured ? ' feat' : ''}" data-project="${esc(p.id)}" aria-label="${esc(t().openProject)}: ${esc(p.title)}">
        <div class="cover">${p.cover_path ? `<img loading="lazy" decoding="async" src="${esc(pub('images', p.cover_path))}" alt="${esc(p.title)}">` : `<div class="nocover"><img src="assets/logo-white.png" alt=""></div>`}${p.is_featured ? `<span class="tag">${esc(t().featured)}</span>` : ''}</div>
        <h3>${esc(p.title)}</h3><div class="meta">${esc([names, yr].filter(Boolean).join(', '))}</div></button>`;
    }).join('')
    : `<p class="lede">${esc(t().empty.productions)}</p>`;

  // Artistes
  const ar = D.artists.filter((a) => a.is_published);
  $('#artistsList').innerHTML = ar.length
    ? ar.map((a) => `<button class="artist" data-artist="${esc(a.id)}"><div class="ph">${a.photo_path ? `<img loading="lazy" decoding="async" src="${esc(pub('images', a.photo_path))}" alt="${esc(a.name)}">` : `<div class="nocover"><img src="assets/logo-white.png" alt=""></div>`}</div><h3>${esc(a.name)}</h3></button>`).join('')
    : `<p class="lede">${esc(t().empty.artists)}</p>`;

  renderGallery();
  renderContact();
  buildTracks();
  renderPlayer();
  applySeo();
}

const artistsOf = (pid) => D.links.filter((l) => l.project_id === pid).map((l) => D.artists.find((a) => a.id === l.artist_id)).filter(Boolean);

function renderGallery() {
  const items = D.gallery.filter((g) => g.is_published);
  const cats = ['all', ...new Set(items.map((g) => g.category))];
  $('#galleryFilters').innerHTML = items.length > 1 ? cats.map((c) => `<button type="button" data-filter="${c}" aria-pressed="${c === galleryFilter}">${esc(t().filters[c] || c)}</button>`).join('') : '';
  const shown = items.filter((g) => galleryFilter === 'all' || g.category === galleryFilter);
  $('#gallery').innerHTML = shown.length
    ? shown.map((g) => `<button type="button" data-gallery="${esc(g.id)}"><img loading="lazy" decoding="async" src="${esc(pub('images', g.image_path))}" alt="${esc(pick(g, 'title'))}"></button>`).join('')
    : `<p class="lede">${esc(t().empty.visual)}</p>`;
}

function renderContact() {
  const s = D.settings;
  const rows = [];
  if (s.contact_email) rows.push([t().email, `<a href="mailto:${esc(s.contact_email)}">${esc(s.contact_email)}</a>`]);
  if (s.phone) rows.push([t().phone, `<a href="tel:${esc(s.phone.replace(/[^+\d]/g, ''))}">${esc(s.phone)}</a>`]);
  if (s.whatsapp) rows.push([t().whatsapp, `<a href="https://wa.me/${esc(s.whatsapp.replace(/\D/g, ''))}" target="_blank" rel="noopener">${esc(s.whatsapp)}</a>`]);
  if (s.location) rows.push([t().location, esc(s.location)]);
  $('#contactInfo').innerHTML = rows.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${v}</dd></div>`).join('');
  $('#socials').innerHTML = D.socials.filter((x) => x.is_visible && safeUrl(x.url)).map((x) => `<li><a href="${esc(safeUrl(x.url))}" target="_blank" rel="noopener">${esc(x.platform)}</a></li>`).join('');
}

function applySeo() {
  const s = D.seo.home || {};
  const title = pick(s, 'title') || 'LGhorfa Prod';
  const desc = pick(s, 'description') || C('home', 'subtitle');
  document.title = title;
  const set = (sel, v) => { const el = $(sel); if (el && v) el.setAttribute('content', v); };
  set('meta[name="description"]', desc);
  set('meta[property="og:title"]', title);
  set('meta[property="og:description"]', desc);
  const img = s.og_image_path ? pub('images', s.og_image_path) : new URL('assets/badge-512.png', location.href).href;
  set('meta[property="og:image"]', img);
  let ld = $('#ld');
  if (!ld) { ld = document.createElement('script'); ld.id = 'ld'; ld.type = 'application/ld+json'; document.head.appendChild(ld); }
  ld.textContent = JSON.stringify({ '@context': 'https://schema.org', '@type': 'MusicGroup', name: 'LGhorfa Prod', description: desc, url: location.origin, logo: new URL('assets/badge-512.png', location.href).href, sameAs: D.socials.filter((x) => x.is_visible && safeUrl(x.url)).map((x) => x.url) });
}

/* ---------- Dialogues ---------- */
const dlg = $('#dlg');
function openDlg(html, cls = '') {
  dlg.innerHTML = `<button class="x" type="button" data-close>${esc(t().close)}</button><div class="dlg ${cls}">${html}</div>`;
  if (!dlg.open) dlg.showModal();
}
dlg.addEventListener('click', (e) => { if (e.target === dlg || e.target.closest('[data-close]')) dlg.close(); });

function openProject(id) {
  const p = D.projects.find((x) => x.id === id); if (!p) return;
  const names = artistsOf(id);
  const trs = D.tracks.filter((x) => x.project_id === id && x.is_published);
  const date = p.release_date ? new Intl.DateTimeFormat(lang, { year: 'numeric', month: 'long' }).format(new Date(p.release_date)) : '';
  openDlg(`
    <div>${p.cover_path ? `<img class="big" src="${esc(pub('images', p.cover_path))}" alt="${esc(p.title)}">` : `<div class="nocover" style="aspect-ratio:1/1;background:#101010"><img src="assets/logo-white.png" alt=""></div>`}</div>
    <div><h3 id="dlgTitle">${esc(p.title)}</h3>
    <p class="meta">${esc([names.length ? `${t().with} ${names.map((a) => a.name).join(', ')}` : '', date ? `${t().released} ${date}` : ''].filter(Boolean).join(' · '))}</p>
    ${paras(pick(p, 'description'))}
    ${trs.length ? `<h4>${esc(t().tracks)}</h4><ul class="pl">${trs.map((x) => `<li><button type="button" data-track="${esc(x.id)}"><span>${esc(x.title)}</span><span aria-hidden="true">${SVG.play.replace('<svg', '<svg width="16" height="16" fill="currentColor"')}</span></button></li>`).join('')}</ul>` : ''}</div>`);
}
function openArtist(id) {
  const a = D.artists.find((x) => x.id === id); if (!a) return;
  const projs = D.links.filter((l) => l.artist_id === id).map((l) => D.projects.find((p) => p.id === l.project_id)).filter((p) => p && p.status === 'published');
  const lk = [['Instagram', a.instagram_url], ['Spotify', a.spotify_url], ['YouTube', a.youtube_url], ...(Array.isArray(a.other_links) ? a.other_links.map((o) => [o.label || o.platform || 'Link', o.url]) : [])].filter(([, u]) => safeUrl(u));
  openDlg(`
    <div>${a.photo_path ? `<img class="big" src="${esc(pub('images', a.photo_path))}" alt="${esc(a.name)}">` : ''}</div>
    <div><h3 id="dlgTitle">${esc(a.name)}</h3>${paras(pick(a, 'bio'))}
    ${projs.length ? `<h4>${esc(t().nav.productions)}</h4><ul class="links">${projs.map((p) => `<li><a href="#" data-project="${esc(p.id)}">${esc(p.title)}</a></li>`).join('')}</ul>` : ''}
    ${lk.length ? `<h4>${esc(t().links)}</h4><ul class="links">${lk.map(([n, u]) => `<li><a href="${esc(safeUrl(u))}" target="_blank" rel="noopener">${esc(n)}</a></li>`).join('')}</ul>` : ''}</div>`, a.photo_path ? '' : 'one');
}
function openGallery(id) {
  const g = D.gallery.find((x) => x.id === id); if (!g) return;
  openDlg(`<div style="grid-column:1/-1"><img class="big" src="${esc(pub('images', g.image_path))}" alt="${esc(pick(g, 'title'))}">${pick(g, 'title') ? `<p class="meta" id="dlgTitle">${esc(pick(g, 'title'))}</p>` : ''}${safeUrl(g.video_url) ? `<p><a class="btn" href="${esc(safeUrl(g.video_url))}" target="_blank" rel="noopener">${esc(t().watch)}</a></p>` : ''}</div>`, 'one');
}

/* ---------- Lecteur ---------- */
function buildTracks() {
  const pubIds = new Map(D.projects.filter((p) => p.status === 'published').map((p) => [p.id, p]));
  const list = D.tracks.filter((x) => x.is_published && (!x.project_id || pubIds.has(x.project_id))).map((x) => {
    const p = pubIds.get(x.project_id);
    return { id: x.id, title: x.title, sub: p ? p.title : '', src: pub('audio', x.audio_path), dur: x.duration_seconds };
  });
  player.setList(list);
}

function renderPlayer() {
  const el = $('#audioPanel');
  if (!player.list.length) { el.innerHTML = `<p class="lede" style="margin:0">${esc(t().empty.audio)}</p>`; return; }
  el.innerHTML = `
    <p class="now" id="nowTitle"></p><p class="now-sub" id="nowSub"></p>
    <canvas class="wave" id="wave" role="slider" aria-label="${esc(t().seek)}" tabindex="0"></canvas>
    <div class="ctrls">
      <button type="button" id="bPrev" aria-label="${esc(t().prev)}">${SVG.prev}</button>
      <button type="button" class="play" id="bPlay" aria-label="${esc(t().play)}">${SVG.play}</button>
      <button type="button" id="bNext" aria-label="${esc(t().next)}">${SVG.next}</button>
      <span class="time" id="time">0:00 / 0:00</span>
      <label class="vol">${esc(t().volume)} <input id="vol" type="range" min="0" max="1" step="0.01" value="${player.a.volume}"></label>
    </div>
    <ul class="pl" id="pl">${player.list.map((x, i) => `<li><button type="button" data-idx="${i}"><span>${esc(x.title)}<small>${esc(x.sub)}</small></span><span class="time">${x.dur ? fmtTime(x.dur) : ''}</span></button></li>`).join('')}</ul>`;
  $('#bPlay').onclick = () => player.toggle();
  $('#bPrev').onclick = () => player.prev();
  $('#bNext').onclick = () => player.next();
  $('#vol').oninput = (e) => player.setVolume(+e.target.value);
  const wave = $('#wave');
  const seek = (e) => { const r = wave.getBoundingClientRect(); player.seek((e.clientX - r.left) / r.width); };
  wave.addEventListener('pointerdown', (e) => { seek(e); wave.setPointerCapture(e.pointerId); wave._d = true; });
  wave.addEventListener('pointermove', (e) => { if (wave._d) seek(e); });
  wave.addEventListener('pointerup', () => { wave._d = false; });
  wave.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') player.a.currentTime += 5; if (e.key === 'ArrowLeft') player.a.currentTime -= 5; });
  syncPlayerUI();
}

function syncPlayerUI() {
  const cur = player.cur, playing = player.playing;
  const nt = $('#nowTitle');
  if (nt) {
    nt.textContent = cur ? cur.title : t().stopped;
    $('#nowSub').textContent = cur ? cur.sub || t().nowPlaying : '';
    $('#bPlay').innerHTML = playing ? SVG.pause : SVG.play;
    $('#bPlay').setAttribute('aria-label', playing ? t().pause : t().play);
    $$('#pl button').forEach((b) => b.classList.toggle('on', +b.dataset.idx === player.i));
    $('#time').textContent = `${fmtTime(player.a.currentTime)} / ${fmtTime(player.a.duration || (cur && cur.dur) || 0)}`;
  }
  const mini = $('#miniPlayer');
  if (cur) {
    mini.hidden = false;
    mini.innerHTML = `<button type="button" id="mPlay" aria-label="${esc(playing ? t().pause : t().play)}">${playing ? SVG.pause : SVG.play}</button><span class="t">${esc(cur.title)}</span><a href="#audio">${esc(t().nav.audio)}</a>`;
    $('#mPlay').onclick = () => player.toggle();
  } else mini.hidden = true;
}
player.on((e) => {
  if (e === 'timeupdate' || e === 'loadedmetadata') {
    const tm = $('#time'); if (tm) tm.textContent = `${fmtTime(player.a.currentTime)} / ${fmtTime(player.a.duration)}`;
    return;
  }
  if (e === 'error') { const s = $('#nowSub'); if (s) s.textContent = t().audioError; return; }
  if (e === 'volumechange') return;
  syncPlayerUI();
});

function drawWave() {
  const c = $('#wave');
  if (c) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2), w = c.clientWidth, h = c.clientHeight;
    if (c.width !== w * dpr) { c.width = w * dpr; c.height = h * dpr; }
    const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
    const cur = player.cur, peaks = cur ? player.peaks.get(cur.id) : null;
    const N = 120, bw = w / N, prog = player.a.duration ? player.a.currentTime / player.a.duration : 0;
    for (let i = 0; i < N; i++) {
      const v = peaks ? peaks[Math.floor((i / N) * peaks.length)] : 0.12 + 0.08 * Math.sin(i * 0.5);
      const bh = Math.max(3, v * h * 0.95);
      g.fillStyle = i / N < prog ? '#efece6' : 'rgba(141,146,152,.55)';
      g.fillRect(i * bw + 1, (h - bh) / 2, Math.max(1, bw - 2), bh);
    }
    if (cur) { g.fillStyle = '#f0a53a'; g.fillRect(prog * w - 1, 0, 2, h); }
    c.setAttribute('aria-valuenow', String(Math.round(prog * 100)));
  }
  if (scene) scene.setLevels(player.levels(64));
  requestAnimationFrame(drawWave);
}

/* ---------- Événements ---------- */
document.addEventListener('click', (e) => {
  const lb = e.target.closest('[data-lang]');
  if (lb) { setLang(lb.dataset.lang); return; }
  const pj = e.target.closest('[data-project]');
  if (pj) { e.preventDefault(); openProject(pj.dataset.project); return; }
  const ar = e.target.closest('[data-artist]'); if (ar) { openArtist(ar.dataset.artist); return; }
  const gl = e.target.closest('[data-gallery]'); if (gl) { openGallery(gl.dataset.gallery); return; }
  const tr = e.target.closest('[data-track]'); if (tr) { player.playId(tr.dataset.track); if (scene) scene.pulse(); return; }
  const ix = e.target.closest('#pl [data-idx]'); if (ix) { player.playIndex(+ix.dataset.idx); if (scene) scene.pulse(); return; }
  const fl = e.target.closest('[data-filter]'); if (fl) { galleryFilter = fl.dataset.filter; renderGallery(); return; }
  if (e.target.closest('#nav a')) closeMenu();
});
function closeMenu() { $('#nav').classList.remove('open'); $('#menuBtn').setAttribute('aria-expanded', 'false'); }
$('#menuBtn').addEventListener('click', () => { const o = $('#nav').classList.toggle('open'); $('#menuBtn').setAttribute('aria-expanded', String(o)); });

function setLang(l) {
  if (l === lang) return;
  lang = l;
  try { localStorage.setItem('lg_lang', l); } catch (e) { /* ignore */ }
  renderStatic(); renderContent(); markActive();
}

let lastSend = 0;
$('#contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target, msg = $('#formMsg'), btn = $('#sendBtn');
  const v = Object.fromEntries(new FormData(f));
  msg.className = 'form-msg';
  if (v.website) return; // anti-spam
  if (!v.name.trim() || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v.email.trim()) || !v.message.trim()) { msg.textContent = t().form.invalid; msg.classList.add('err'); return; }
  if (Date.now() - lastSend < 15000) { msg.textContent = t().form.wait; msg.classList.add('err'); return; }
  btn.disabled = true; btn.textContent = t().form.sending;
  const { error } = await sb.from('contact_submissions').insert({ name: v.name.trim(), email: v.email.trim(), subject: (v.subject || '').trim() || null, message: v.message.trim(), locale: lang });
  btn.disabled = false; btn.textContent = t().form.send;
  if (error) { msg.textContent = t().form.err; msg.classList.add('err'); return; }
  lastSend = Date.now(); f.reset(); msg.textContent = t().form.ok;
});

/* ---------- Scène + navigation active ---------- */
function markActive(id) {
  if (id) markActive.id = id;
  $$('#nav a').forEach((a) => a.setAttribute('aria-current', String(a.getAttribute('href') === `#${markActive.id}`)));
}
function watchSections() {
  const io = new IntersectionObserver((entries) => {
    entries.filter((en) => en.isIntersecting).forEach((en) => { markActive(en.target.id); if (scene) scene.setState(en.target.dataset.scene); });
  }, { rootMargin: '-45% 0px -45% 0px' });
  $$('section[data-scene]').forEach((s) => io.observe(s));
}

async function initScene() {
  try {
    const { createScene } = await import('./scene.js');
    scene = await createScene($('#gl'), { low, reduced });
  } catch (err) {
    console.warn('3D unavailable', err);
    $('#gl').hidden = true; $('#fallbackLogo').hidden = false;
  }
}

function subscribe() {
  let tm;
  const reload = () => { clearTimeout(tm); tm = setTimeout(() => load().then(renderContent).catch(() => {}), 500); };
  const ch = sb.channel('public-sync');
  ['site_content', 'site_settings', 'seo_pages', 'social_links', 'services', 'artists', 'projects', 'project_artists', 'tracks', 'gallery_items'].forEach((tb) => ch.on('postgres_changes', { event: '*', schema: 'public', table: tb }, reload));
  ch.subscribe();
}

/* ---------- Démarrage ---------- */
(async function boot() {
  renderStatic();
  const intro = $('#intro');
  const seen = (() => { try { return sessionStorage.getItem('lg_intro'); } catch (e) { return null; } })();
  if (seen || reduced) intro.classList.add('done');
  const started = performance.now();
  const dataP = load().then(renderContent).catch((err) => { console.error(err); $('#heroSub').textContent = t().loadError; });
  const sceneP = initScene();
  await Promise.all([dataP, sceneP]);
  watchSections();
  markActive('home');
  requestAnimationFrame(drawWave);
  const wait = Math.max(0, 1100 - (performance.now() - started));
  setTimeout(() => { if (scene) { if (seen || reduced) scene.skipIntro(); else scene.startIntro(); } intro.classList.add('done'); try { sessionStorage.setItem('lg_intro', '1'); } catch (e) { /* ignore */ } }, seen || reduced ? 0 : wait);
  subscribe();
})();
